"use client";

import { useEffect, useState } from "react";
import { Moon, Sun } from "lucide-react";

export default function Switcher() {
    const [isDark, setIsDark] = useState(false);
    const [mounted, setMounted] = useState(false);

    useEffect(() => {
        const theme = localStorage.getItem("theme") ?? "light";

        setIsDark(theme === "dark");
        document.documentElement.classList.toggle(
            "dark",
            theme === "dark"
        );

        setMounted(true);
    }, []);

    const toggleDarkMode = (): void => {
        const nextDark = !isDark;

        setIsDark(nextDark);

        localStorage.setItem(
            "theme",
            nextDark ? "dark" : "light"
        );

        document.documentElement.classList.toggle(
            "dark",
            nextDark
        );
    };

    if (!mounted) return <></>;

    return (
        <button
            type="button"
            onClick={toggleDarkMode}
            aria-label="Toggle theme"
            className="
                fixed bottom-10 right-10 z-50
                flex h-14 w-14 items-center justify-center
                rounded-full border
                bg-white shadow-md
                transition-all duration-300
                hover:scale-105
                dark:bg-slate-800
            "
        >
            {isDark ? (
                <Sun className="h-6 w-6 text-yellow-400" />
            ) : (
                <Moon className="h-6 w-6 text-slate-800" />
            )}
        </button>
    );
}