import React from 'react'

export default function DashboardPage() {
    return (
        <>
            <h2 className="intro-y text-lg font-medium pt-8 sm:pt-24">
                Sistem Management KPI
            </h2>
        </>
    )
}
